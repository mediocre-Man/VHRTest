package org.sang.bean;

public class Chart {
    private Object keys;
    private Object values;

    public Object getKeys() {
        return keys;
    }

    public void setKeys(Object keys) {
        this.keys = keys;
    }

    public Object getValues() {
        return values;
    }

    public void setValues(Object values) {
        this.values = values;
    }
}
