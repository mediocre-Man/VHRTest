package org.sang.bean;

import java.util.List;

public class WageSchedule {
    private Integer id;
    private Integer eid;
    private String name;
    private String depname;
    private Double basicSalary;
    private Double bonus;
    private Double lunchSalary;
    private Double trafficSalary;
    private Double allSalary;
    private Double take_home;
    private Double pensionBase;
    private Double pensionPer;
    private Double medicalBase;
    private Double medicalPer;
    private Double accumulationFundBase;
    private Double accumulationFundPer;
    private String createDate;
    private List<Month> months;

    public Integer getEid() {
        return eid;
    }

    public void setEid(Integer eid) {
        this.eid = eid;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepname() {
        return depname;
    }

    public void setDepname(String depname) {
        this.depname = depname;
    }

    public Double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(Double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public Double getBonus() {
        return bonus;
    }

    public void setBonus(Double bonus) {
        this.bonus = bonus;
    }

    public Double getLunchSalary() {
        return lunchSalary;
    }

    public void setLunchSalary(Double lunchSalary) {
        this.lunchSalary = lunchSalary;
    }

    public Double getTrafficSalary() {
        return trafficSalary;
    }

    public void setTrafficSalary(Double trafficSalary) {
        this.trafficSalary = trafficSalary;
    }

    public Double getAllSalary() {
        return allSalary;
    }

    public void setAllSalary(Double allSalary) {
        this.allSalary = allSalary;
    }

    public Double getTake_home() {
        return take_home;
    }

    public void setTake_home(Double take_home) {
        this.take_home = take_home;
    }

    public Double getPensionBase() {
        return pensionBase;
    }

    public void setPensionBase(Double pensionBase) {
        this.pensionBase = pensionBase;
    }

    public Double getPensionPer() {
        return pensionPer;
    }

    public void setPensionPer(Double pensionPer) {
        this.pensionPer = pensionPer;
    }

    public Double getMedicalBase() {
        return medicalBase;
    }

    public void setMedicalBase(Double medicalBase) {
        this.medicalBase = medicalBase;
    }

    public Double getMedicalPer() {
        return medicalPer;
    }

    public void setMedicalPer(Double medicalPer) {
        this.medicalPer = medicalPer;
    }

    public Double getAccumulationFundBase() {
        return accumulationFundBase;
    }

    public void setAccumulationFundBase(Double accumulationFundBase) {
        this.accumulationFundBase = accumulationFundBase;
    }

    public Double getAccumulationFundPer() {
        return accumulationFundPer;
    }

    public void setAccumulationFundPer(Double accumulationFundPer) {
        this.accumulationFundPer = accumulationFundPer;
    }

    public List<Month> getMonths() {
        return months;
    }

    public void setMonths(List<Month> months) {
        this.months = months;
    }
}
