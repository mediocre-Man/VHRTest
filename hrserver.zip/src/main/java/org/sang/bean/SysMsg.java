package org.sang.bean;

import lombok.Data;

/**
 * 系统消息
 *
 * @author：zx
 * @createDate：2019/11/4
 * @company：bdqn
 */
@Data
public class SysMsg {
    /**
     * id
     */
    private Long id;
    /**
     * 消息id
     */
    private Long mid;
    /**
     * 消息类型(0表示群发消息)
     */
    private Integer type;
    /**
     * 这条消息是发给谁的(接收人id)
     */
    private Long hrid;
    /**
     * 消息状态(0未读1已读)
     */
    private Integer state;
    /**
     * 消息内容
     */
    private MsgContent msgContent;

}
