package org.sang.bean;

/**
 * 员工培训信息表
 *
 * @author：zx
 * @createDate：2019/11/4
 * @company：bdqn
 */

public class EmployeeTrain {
    /**
     * id
     */
    private Integer id;
    /**
     * 员工编号
     */
    private Integer eid;
    /**
     * 培训日期
     */
    private String trainDate;
    /**
     * 培训内容
     */
    private String trainContent;
    /**
     * 备注
     */
    private String remark;

    private Employee employee;
    private Department department;
    private JobLevel jobLevel;
    private Position position;

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public JobLevel getJobLevel() {
        return jobLevel;
    }

    public void setJobLevel(JobLevel jobLevel) {
        this.jobLevel = jobLevel;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEid() {
        return eid;
    }

    public void setEid(Integer eid) {
        this.eid = eid;
    }

    public String getTrainDate() {
        return trainDate;
    }

    public void setTrainDate(String trainDate) {
        this.trainDate = trainDate;
    }

    public String getTrainContent() {
        return trainContent;
    }

    public void setTrainContent(String trainContent) {
        this.trainContent = trainContent;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
