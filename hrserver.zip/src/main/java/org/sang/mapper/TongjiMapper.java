package org.sang.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.sang.bean.Tongji;

import java.util.List;

@Mapper
public interface TongjiMapper {
    public List<Tongji> fenSex();
    public List<Tongji>  fenWedlock();
    public List<Tongji>  fenTiptopDegree();
    public List<Tongji>  fenNativePlace();
}
