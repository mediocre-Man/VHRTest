package org.sang.mapper;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.EmployeeRemove;

import java.util.List;

public interface EmployeeRemoveMapper {
    List<EmployeeRemove> getEmpByPage(@Param("page") Integer page, @Param("size") Integer size);

    int getCounts();

    int insertEmp(EmployeeRemove employeeRemove);

    int deleteEmp(@Param("ids") String[] ids);

    int updateEmp(EmployeeRemove employeeRemove);
}
