package org.sang.mapper;

import org.sang.bean.Chart;

import java.util.List;

public interface ChartMapper {
    List<Chart> getGender();
    List<Chart> getDepartment();
}
