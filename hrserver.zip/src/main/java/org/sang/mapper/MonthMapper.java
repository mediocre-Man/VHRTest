package org.sang.mapper;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.Employee;
import org.sang.bean.Month;

import java.util.List;

public interface MonthMapper {
    List<Employee> getEmployeeList();
    List<Month> getMonthList(@Param("departmentId") Integer departmentId, @Param("createdDate") String createdDate, @Param("name") String name, @Param("PageNo") Integer PageNo, @Param("PageSize") Integer PageSize);
    int delMonth(@Param("ids") String[] ids, @Param("createdDate") String createdDate);
    int insMonth(Month month);
    int updMonth(Month month);
    int getCount(@Param("departmentId") Integer departmentId, @Param("createdDate") String createdDate, @Param("name") String name);
}
