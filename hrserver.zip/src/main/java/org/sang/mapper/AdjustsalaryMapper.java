package org.sang.mapper;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.Adjustsalary;

import java.util.List;

public interface AdjustsalaryMapper {
    List<Adjustsalary> getEmpByPage(@Param("page") Integer page, @Param("size") Integer size);

    int getCounts();

    int insertEmp(Adjustsalary adjustsalary);

    int deleteEmp(@Param("ids") String[] ids);

    int updateEmp(Adjustsalary adjustsalary);
}
