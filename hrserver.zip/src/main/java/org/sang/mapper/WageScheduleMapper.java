package org.sang.mapper;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.Month;
import org.sang.bean.WageSchedule;

import java.util.List;

public interface WageScheduleMapper {
    List<WageSchedule> getWageScheduleList(@Param("depId") Integer depId);
    Double getAdjustsalary(@Param("eid") Integer eid);
    List<Month> getMonthList(@Param("eid") Integer eid, @Param("createdDate") String createdDate);
    List<WageSchedule> getTotalwagesList(@Param("depname") String depname, @Param("createDate") String createDate);
    int insTotalwages(@Param("list") List<WageSchedule> list, @Param("createDate") String createDate);
}
