package org.sang.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.sang.bean.Employee;
import org.sang.bean.Employeeec;

import java.util.List;

/**
 * @author 周雄
 * @date 2019/11/6 13:45
 */
@Mapper
public interface EmployeeecMapper {

    List<Employeeec>getEmployeeec(@Param("page")Integer page,@Param("size")Integer size);
    int Count();
    int add(Employeeec employeeec);
    List<Employee>ListEmp();
    int del(@Param("ids") String[] ids);
    int update(@Param("emp") Employeeec employeeec);
    List<Employeeec>getPoint();
}
