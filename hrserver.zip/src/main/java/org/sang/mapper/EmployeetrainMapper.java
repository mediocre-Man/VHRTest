package org.sang.mapper;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.Employee;
import org.sang.bean.EmployeeTrain;

import java.util.List;

/**
 * @author 周雄
 * @date 2019/11/7 17:01
 */
public interface EmployeetrainMapper {

    List<EmployeeTrain> getEmployeeTrain(@Param("page")Integer page, @Param("size")Integer size);
    int Count();
    int add(EmployeeTrain employeeTrain);
    List<Employee>ListEmp();
    int del(@Param("ids") String[] ids);
    int update(@Param("emp") EmployeeTrain employeeTrain);
}
