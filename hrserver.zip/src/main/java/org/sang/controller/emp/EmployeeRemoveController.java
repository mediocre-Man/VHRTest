package org.sang.controller.emp;

import org.sang.bean.EmployeeRemove;
import org.sang.bean.RespBean;
import org.sang.service.EmployeeRemoveService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/employeeR/basic")
public class EmployeeRemoveController {

    @Resource
    EmployeeRemoveService employeeRemoveService;

    //分页查询员工培训
    @GetMapping("/emp")
    public Map<String, Object> getEmployeeTByPage(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "6") Integer size) {
        Map<String, Object> map = new HashMap<>();
        List<EmployeeRemove> employeeByPage = employeeRemoveService.getEmpByPage(page, size);
        Integer count = employeeRemoveService.getCounts();
        map.put("emps", employeeByPage);
        map.put("count", count);
        return map;
    }

    //新增培训
    @PostMapping("/emp")
    public RespBean addEmp(EmployeeRemove employeeRemove) {
        if (employeeRemoveService.insertEmp(employeeRemove) == 1) {
            return RespBean.ok("添加成功!");
        }
        return RespBean.error("添加失败!");
    }

    //删除培训
    @DeleteMapping(value = "/emp/{ids}")
    public RespBean deleteEmpById(@PathVariable String ids) {
        if (employeeRemoveService.deleteEmp(ids)) {
            return RespBean.ok("删除成功!");
        }
        return RespBean.error("删除失败!");
    }

    //更新培训
    @PutMapping("/emp")
    public RespBean updateEmp(EmployeeRemove employeeRemove) {
        System.out.println("updateEmpEc" + employeeRemove.toString());
        if (employeeRemoveService.updateEmp(employeeRemove) == 1) {
            return RespBean.ok("更新成功!");
        }
        return RespBean.error("更新失败!");
    }
}
