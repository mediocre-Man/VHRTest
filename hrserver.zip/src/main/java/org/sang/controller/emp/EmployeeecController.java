package org.sang.controller.emp;




import cn.hutool.json.JSONArray;
import org.sang.bean.Employeeec;
import org.sang.bean.RespBean;
import org.sang.bean.Tongji;
import org.sang.service.EmployeeecService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.TemplateEngine;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;

/**
 * @author 周雄
 * @date 2019/11/6 13:38
 */
@RestController
@RequestMapping("/employeeec/basic")
public class EmployeeecController {
    @Autowired
    EmployeeecService employeeecService;

    @Autowired
    ExecutorService executorService;

    @Autowired
    TemplateEngine templateEngine;

    @Autowired
    JavaMailSender javaMailSender;
    @Value("${spring.mail.username}")
    String emailAddress;

    /**
     * 员工奖惩
     */
    @RequestMapping(value = "/YuanGongJiangChen", method = RequestMethod.GET)
    public Object YuanGongJiangChen(@RequestParam(defaultValue = "1") Integer page,
                                    @RequestParam(defaultValue = "6") Integer size){
        Map<String,Object>map=new HashMap<>();
        List<Employeeec>list=employeeecService.getEmployeeec(page,size);
        Integer count =employeeecService.Count();
        map.put("count", count);
        map.put("emps",list);
        map.put("listEmp", employeeecService.ListEmp());
        return map;
    }
    /**
     * 添加员工奖惩
     */
    @RequestMapping(value = "/addJiangChen", method = RequestMethod.POST)
    public RespBean addEmp(Employeeec employeeec) {
        if (employeeecService.add(employeeec) == 1) {
            return RespBean.ok("添加成功!");
        }
        return RespBean.error("添加失败!");
    }

    @RequestMapping(value = "/emp/{ids}", method = RequestMethod.DELETE)
    public RespBean deleteEmpById(@PathVariable String []ids) {
        if (employeeecService.del(ids)>0) {
            return RespBean.ok("删除成功!");
        }
        return RespBean.error("删除失败!");
    }

    @RequestMapping(value = "/addJiangChen", method = RequestMethod.PUT)
    public RespBean updateEmp(Employeeec employee) {
        if (employeeecService.update(employee) == 1) {
            return RespBean.ok("更新成功!");
        }
        return RespBean.error("更新失败!");
    }

//    @RequestMapping(value = "/exportEmp", method = RequestMethod.GET)
//    public ResponseEntity<byte[]> exportEmp() {
//        return PoiUtils.exportEmp2Excel(employeeecService.getAllEmployees());
//    }

    @RequestMapping("/point")
    public Object point(){
        Map<String,Object>map=new HashMap<>();
        List<Employeeec>list=employeeecService.getPoint();
        map.put("list",list);
        return map;
    }
 /*   public void getNum(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("text/html; charset=utf-8");
        List<Employeeec> list=new ArrayList<Employeeec>();
        list=employeeecService.getPoint();
       *//* JSONArray jsonArray = JSONArray.fromObject(list);//转化成json对象*//*
        PrintWriter out=response.getWriter();
        out.println(list);
        out.flush();
        out.close();

    }*/

}
