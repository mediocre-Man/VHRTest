package org.sang.controller.emp;

import org.sang.bean.EmployeeTrain;
import org.sang.bean.RespBean;
import org.sang.service.EmployeetrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.TemplateEngine;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;

/**
 * @author 周雄
 * @date 2019/11/7 18:11
 */
@RestController
@RequestMapping("/employeetrain/basic")
public class EmployeetrainController {
    @Autowired
    EmployeetrainService employeetrainService;

    @Autowired
    ExecutorService executorService;

    @Autowired
    TemplateEngine templateEngine;

    @Autowired
    JavaMailSender javaMailSender;
    @Value("${spring.mail.username}")
    String emailAddress;

    /**
     * 员工培训
     */
    @RequestMapping(value = "/train", method = RequestMethod.GET)
    public Object YuanGongJiangChen(@RequestParam(defaultValue = "1") Integer page,
                                    @RequestParam(defaultValue = "6") Integer size){
        Map<String,Object> map=new HashMap<>();
        List<EmployeeTrain> list=employeetrainService.getEmployeeTrain(page,size);
        Integer count =employeetrainService.Count();
        map.put("count", count);
        map.put("emps",list);
        map.put("listEmp", employeetrainService.ListEmp());
        return map;
    }
    /**
     * 添加员工培训
     */
    @RequestMapping(value = "/addTrain", method = RequestMethod.POST)
    public RespBean addEmp(EmployeeTrain employeeec) {
        if (employeetrainService.add(employeeec) == 1) {
            return RespBean.ok("添加成功!");
        }
        return RespBean.error("添加失败!");
    }

    @RequestMapping(value = "/emp/{ids}", method = RequestMethod.DELETE)
    public RespBean deleteEmpById(@PathVariable String []ids) {
        if (employeetrainService.del(ids)>0) {
            return RespBean.ok("删除成功!");
        }
        return RespBean.error("删除失败!");
    }

    @RequestMapping(value = "/addTrain", method = RequestMethod.PUT)
    public RespBean updateEmp(EmployeeTrain employee) {
        if (employeetrainService.update(employee) == 1) {
            return RespBean.ok("更新成功!");
        }
        return RespBean.error("更新失败!");
    }

}
