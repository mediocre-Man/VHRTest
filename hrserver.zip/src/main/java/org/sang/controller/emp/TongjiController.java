package org.sang.controller.emp;

import org.sang.bean.Tongji;
import org.sang.service.TongjiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/statistics/score")
public class TongjiController {
    @Autowired
    TongjiService tongjiService;
    @RequestMapping("/sex")
    public Object fenSex(){
        HashMap<String,Object> map=new HashMap<String,Object>();
        List<Tongji> list=tongjiService.fenSex();
        map.put("list",list);
        return  map;
    }
    @RequestMapping("/wedlock")
    public Object  fenWedlock(){
        HashMap<String,Object> map=new HashMap<String,Object>();
        List<Tongji> list=tongjiService.fenWedlock();
        map.put("list",list);
        return  map;

    }
    @RequestMapping("/tiptopDegree")
    public Object fenTiptopDegree(){
        HashMap<String,Object> map=new HashMap<String,Object>();
        List<Tongji> list=tongjiService.fenTiptopDegree();
        map.put("list",list);
        return  map;

    }
    @RequestMapping("/nativePlace")
    public Object  fenNativePlace(){
        HashMap<String,Object> map=new HashMap<String,Object>();
        List<Tongji> list=tongjiService.fenNativePlace();
        map.put("list",list);
        return  map;

    }
}
