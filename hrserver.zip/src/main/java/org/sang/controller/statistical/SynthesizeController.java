package org.sang.controller.statistical;

import org.sang.bean.Chart;
import org.sang.service.ChartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/statistics/all")
public class SynthesizeController {
    @Autowired
    ChartService chartService;

    @GetMapping("/getChart")
    public Object getChart(String type){
      List<Chart> list = new ArrayList<>();
        if(type.equals("0")){
            list = chartService.getGender();
        }else if(type.equals("1")){
            list = chartService.getDepartment();
        }
        Map<String,Object> map = new HashMap<>();
        map.put("values",list);
        return map;
    }
}
