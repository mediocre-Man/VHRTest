package org.sang.controller.statistical;

import org.sang.bean.Employee;
import org.sang.bean.Month;
import org.sang.bean.RespBean;
import org.sang.service.DepartmentService;
import org.sang.service.MonthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/salary/month")
public class MonthController {
    @Autowired
    MonthService monthService;
    @Autowired
    DepartmentService departmentService;
    @GetMapping("/getMonth")
    public Object getMonth(Integer departmentId,String name,Integer PageNo){
        int zong = monthService.getCount(departmentId,name);
        int zongye = zong%10==0?zong/10:(zong/10)+1;
        Map<String,Object> map = new HashMap<>();
        if(zong!=0){
            int zongys = zong%10==0?zong/10:(zong/10)+1;
            if(PageNo==null ||PageNo<0){
                PageNo = 1;
            }else if(PageNo>zongys){
                PageNo = zongys;
            }
            List<Month> monthList = monthService.getMonthList(departmentId,name,PageNo,10);
            map.put("data",monthList);
        }
        List<Employee> Employeelist = monthService.getEmployeeList();
        map.put("emps",Employeelist);
        map.put("deps",departmentService.getAllDeps());
        map.put("currentPage", PageNo);
        map.put("totalCount", zong);
        map.put("keywords", name);
        return map;
    }
    @PostMapping("/insMonth")
    public Object insMonth(Month month){
        if(monthService.insMonth(month)>0){
            return RespBean.ok("成功");
        }
        return RespBean.error("失败");
    }
    @PutMapping("/updMonth")
    public Object updMonth(Month month){
        if(monthService.updMonth(month)>0){
            return RespBean.ok("成功");
        }
        return RespBean.error("失败");
    }

    @DeleteMapping("/delMonth/{ids}")
    public Object delMonth(@PathVariable("ids") String ids){
        String[] ides = ids.split(",");
        if(monthService.delMonth(ides)==ides.length){
            return RespBean.ok("成功");
        }else{
            return RespBean.error("失败");
        }
    }
}
