package org.sang.controller.statistical;

import org.sang.bean.RespBean;
import org.sang.bean.WageSchedule;

import org.sang.common.utils.PoiUtils;
import org.sang.service.DepartmentService;
import org.sang.service.WageScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/salary/table")
public class WageScheduleController {
    @Autowired
    WageScheduleService wageScheduleService;
    @Autowired
    DepartmentService departmentService;
    @GetMapping("/getWageScheduleList")
    public Object getWageScheduleList(Integer typeid){
        List<WageSchedule> list = wageScheduleService.getWageScheduleList(typeid);
        Map<String,Object> map = new HashMap<>();
        map.put("data",list);
        map.put("deps",departmentService.getAllDeps());
        return map;
    }

    @PostMapping("/insTotalwagesList")
    public Object insTotalwagesList(Integer did){
        if(wageScheduleService.insTotalwages(did)){
            return RespBean.ok("添加工资记录成功");
        }else{
            return RespBean.ok("添加工资记录失败");
        }
    }

    @RequestMapping(value = "/exportEmp", method = RequestMethod.GET)
    public ResponseEntity<byte[]> exportEmp(String dname,String date) {
        List<WageSchedule> list = wageScheduleService.getTotalwagesList(dname,date);
        return PoiUtils.exportEmpExcel(list);
    }

    @GetMapping("/getTotalwagesList")
    public Object getTotalwagesList(String dname,String date){
        List<WageSchedule> list = wageScheduleService.getTotalwagesList(dname,date);
        Map<String,Object> map = new HashMap<>();
        map.put("data",list);
        map.put("deps",departmentService.getAllDeps());
        return map;
    }

}
