package org.sang.service;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.Employee;
import org.sang.bean.Employeeec;

import java.util.List;

public interface EmployeeecService {
    int Count();
    List<Employeeec> getEmployeeec(@Param("page") Integer page, @Param("size") Integer size);
    int add(Employeeec employeeec);
    List<Employee>ListEmp();
    int del(@Param("ids") String[] ids);
    int update(@Param("emp") Employeeec employeeec);
    List<Employeeec>getPoint();
}
