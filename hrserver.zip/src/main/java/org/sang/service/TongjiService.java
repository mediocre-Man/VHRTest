package org.sang.service;

import org.sang.bean.Tongji;
import org.sang.mapper.TongjiMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional
public class TongjiService {
    @Resource
    TongjiMapper tongjiMapper;
    public List<Tongji> fenSex(){
        return  tongjiMapper.fenSex();
    }
    public List<Tongji>  fenWedlock(){
        return  tongjiMapper.fenWedlock();
    }

    public List<Tongji>  fenTiptopDegree(){
        return tongjiMapper.fenTiptopDegree();
    }
    public List<Tongji>  fenNativePlace(){
        return  tongjiMapper.fenNativePlace();
    }
}
