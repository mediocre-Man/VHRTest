package org.sang.service;

import org.sang.bean.EmployeeRemove;
import org.sang.mapper.EmployeeRemoveMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class EmployeeRemoveService {
    @Resource
    EmployeeRemoveMapper employeeRemoveMapper;

    public List<EmployeeRemove> getEmpByPage(Integer page, Integer size) {
        return employeeRemoveMapper.getEmpByPage((page - 1) * size, size);
    }

    public Integer getCounts() {
        return employeeRemoveMapper.getCounts();
    }

    public int insertEmp(EmployeeRemove employeeRemove) {
        return employeeRemoveMapper.insertEmp(employeeRemove);
    }

    public boolean deleteEmp(String ids) {
        String[] split = ids.split(",");
        return employeeRemoveMapper.deleteEmp(split) == split.length;
    }

    public int updateEmp(EmployeeRemove employeeRemove) {
        return employeeRemoveMapper.updateEmp(employeeRemove);
    }
}
