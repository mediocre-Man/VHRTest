package org.sang.service;

import org.sang.bean.Chart;
import org.sang.mapper.ChartMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ChartService {
    @Autowired
    ChartMapper chartMapper;

    public List<Chart> getGender(){
        List<Chart> list = chartMapper.getGender();
        return list;
     }
     public List<Chart> getDepartment(){
         List<Chart> list = chartMapper.getDepartment();
         return list;
     }
}
