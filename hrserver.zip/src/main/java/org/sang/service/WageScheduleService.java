package org.sang.service;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.Month;
import org.sang.bean.WageSchedule;
import org.sang.mapper.WageScheduleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class WageScheduleService {
    @Resource
    WageScheduleMapper wageScheduleMapper;

    public List<WageSchedule> getWageScheduleList(Integer depId){
        List<WageSchedule> list = wageScheduleMapper.getWageScheduleList(depId);
        for (int i=0;i<list.size();i++){
            list.get(i).setPensionBase((list.get(i).getPensionBase()*list.get(i).getPensionPer()));
            list.get(i).setMedicalBase((list.get(i).getMedicalBase()*list.get(i).getMedicalPer()));
            list.get(i).setAccumulationFundBase((list.get(i).getAccumulationFundBase()*list.get(i).getAccumulationFundPer()));
            Double zhi = wageScheduleMapper.getAdjustsalary(list.get(i).getId());
            zhi = zhi ==null?0:zhi;
            zhi += list.get(i).getLunchSalary()+list.get(i).getTrafficSalary()+list.get(i).getBonus();
            zhi-=  list.get(i).getPensionBase()+list.get(i).getAccumulationFundBase()+list.get(i).getMedicalBase();
            SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM");
            Date date = new Date(System.currentTimeMillis());
            List<Month> list1 = wageScheduleMapper.getMonthList(list.get(i).getId(),formatter.format(date).toString());
            list.get(i).setAllSalary(zhi);
            list.get(i).setMonths(list1);
            int jianqian =0 ;
            for (int j = 0;j<list1.size();j++){
                jianqian += list1.get(j).getMoney()*list1.get(j).getDegree();
            }
            list.get(i).setTake_home(list.get(i).getAllSalary()+jianqian);
        }
        return list;
    }

   public List<WageSchedule> getTotalwagesList(String depname,String createDate){
        List<WageSchedule> list = wageScheduleMapper.getTotalwagesList(depname,createDate);
       for (int i=0;i<list.size();i++){
           List<Month> list1 = wageScheduleMapper.getMonthList(list.get(i).getEid(),list.get(i).getCreateDate());
           list.get(i).setMonths(list1);
       }
       return list;
    }
    public boolean insTotalwages(Integer depId){
        List<WageSchedule> list1 = getWageScheduleList(depId);
        if(list1!=null){
            SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM");
            Date date = new Date(System.currentTimeMillis());
            if(wageScheduleMapper.insTotalwages(list1,formatter.format(date))==list1.size()){
                return true;
            }else{
                return false;
            }
        }else{
            return true;
        }

    }

}
