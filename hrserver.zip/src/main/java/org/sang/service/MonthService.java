package org.sang.service;

import org.apache.ibatis.annotations.Param;
import org.sang.bean.Employee;
import org.sang.bean.Month;
import org.sang.mapper.MonthMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class MonthService {
    @Resource
    MonthMapper monthMapper;

   public List<Employee> getEmployeeList(){
        return monthMapper.getEmployeeList();
    }
    public List<Month> getMonthList(Integer departmentId,String name,Integer PageNo,Integer PageSize){
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM");
        Date date = new Date(System.currentTimeMillis());
        return monthMapper.getMonthList(departmentId,formatter.format(date).toString(),name,(PageNo-1)*PageSize,PageSize);
    }
    public int getCount(Integer departmentId,String name){
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM");
        Date date = new Date(System.currentTimeMillis());
        return monthMapper.getCount(departmentId,formatter.format(date),name);
    }
    public int delMonth(String[] ids){
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM");
        Date date = new Date(System.currentTimeMillis());
        return monthMapper.delMonth(ids,formatter.format(date).toString());
    }
    public int insMonth(Month months){
        return monthMapper.insMonth(months);
    }
    public  int updMonth(Month month){
       return monthMapper.updMonth(month);
    }
}
