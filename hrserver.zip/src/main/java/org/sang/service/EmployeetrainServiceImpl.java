package org.sang.service;

import org.sang.bean.Employee;
import org.sang.bean.EmployeeTrain;
import org.sang.mapper.EmployeetrainMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
/**
 * @author 周雄
 * @date 2019/11/7 18:08
 */
@Service
public class EmployeetrainServiceImpl implements EmployeetrainService{

    @Resource
    EmployeetrainMapper employeetrainMapper;
    @Override
    public List<EmployeeTrain> getEmployeeTrain(Integer page, Integer size) {
        return employeetrainMapper.getEmployeeTrain((page-1)*size,size);
    }

    @Override
    public int Count() {
        return employeetrainMapper.Count();
    }

    @Override
    public int add(EmployeeTrain employeeTrain) {
        return employeetrainMapper.add(employeeTrain);
    }

    @Override
    public List<Employee> ListEmp() {
        return employeetrainMapper.ListEmp();
    }

    @Override
    public int del(String[] ids) {
        return employeetrainMapper.del(ids);
    }

    @Override
    public int update(EmployeeTrain employeeTrain) {
        return employeetrainMapper.update(employeeTrain);
    }
}
