package org.sang.service;

import org.sang.bean.Employee;
import org.sang.bean.Employeeec;
import org.sang.mapper.EmployeeecMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class EmployeeecServiceImpl implements EmployeeecService{
    @Resource
    EmployeeecMapper employeeecMapper;

    @Override
    public int Count() {
        return employeeecMapper.Count();
    }

    @Override
    public List<Employeeec> getEmployeeec(Integer page, Integer size) {
        return employeeecMapper.getEmployeeec((page-1)*size,size);
    }

    @Override
    public int add(Employeeec employeeec) {
        return employeeecMapper.add(employeeec);
    }

    @Override
    public List<Employee> ListEmp() {
        return employeeecMapper.ListEmp();
    }

    @Override
    public int del(String[] ids) {
        return employeeecMapper.del(ids);
    }

    @Override
    public int update(Employeeec employeeec) {
        return employeeecMapper.update(employeeec);
    }

    @Override
    public List<Employeeec> getPoint() {
        return employeeecMapper.getPoint();
    }


}
