package org.sang.service;

import org.sang.bean.Adjustsalary;
import org.sang.mapper.AdjustsalaryMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class AdjustsalaryService {

    @Resource
    AdjustsalaryMapper adjustsalaryMapper;

    public List<Adjustsalary> getEmpByPage(Integer page, Integer size) {
        int start = (page - 1) * size;
        return adjustsalaryMapper.getEmpByPage(start, size);
    }

    public int getCounts() {
        return adjustsalaryMapper.getCounts();
    }

    public int insertEmp(Adjustsalary adjustsalary) {
        return adjustsalaryMapper.insertEmp(adjustsalary);
    }

    public boolean deleteEmp(String ids) {
        String[] split = ids.split(",");
        return adjustsalaryMapper.deleteEmp(split) == split.length;
    }

    public int updateEmp(Adjustsalary adjustsalary) {
        return adjustsalaryMapper.updateEmp(adjustsalary);
    }
}
